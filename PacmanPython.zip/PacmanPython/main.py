import pygame
from fantasma import Fantasma
from funcoes import *
from config import *

pygame.init()
pygame.mixer.init()
pygame.display.set_caption("Pac-Man em Python")

icone = pygame.image.load('assets/img/jogador/1.png') 
pygame.display.set_icon(icone)

som_bolinha = pygame.mixer.Sound('assets/sound/pacman_chomp.wav')
som_morte = pygame.mixer.Sound('assets/sound/pacman_death.wav')
som_comeco = pygame.mixer.Sound('assets/sound/pacman_beginning.wav')
som_comer_fantasma = pygame.mixer.Sound('assets/sound/pacman_eatghost.wav')
som_powerup = pygame.mixer.Sound('assets/sound/pacman_powerup.wav')
som_bolinha.set_volume(0.2)
som_morte.set_volume(0.2)
som_comeco.set_volume(0.2)
som_comer_fantasma.set_volume(0.2)
som_powerup.set_volume(0.2)
pygame.mixer.music.load('assets/sound/menu_sound.wav')
pygame.mixer.music.set_volume(0.2)

estado_jogo = 'menu'
jogo_pausado = False
executando = True
while executando:
    temporizador.tick(fps)
    tela.fill('black')

    if estado_jogo == 'menu':    
        carregar_menu()

        if not pygame.mixer.music.get_busy():
            pygame.mixer.music.play(-1)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                executando = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    pygame.mixer.music.stop()
                    estado_jogo = 'instrucoes'
                if event.key == pygame.K_ESCAPE:
                    executando = False
        
        pygame.display.flip()

    elif estado_jogo == 'instrucoes':
        carregar_instrucoes()

        if not pygame.mixer.music.get_busy():
            pygame.mixer.music.play(-1)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                executando = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    pygame.mixer.music.stop()
                    estado_jogo = 'jogo'
                    som_comeco.play()
                if event.key == pygame.K_ESCAPE:
                    estado_jogo = 'menu'
        
        pygame.display.flip()

    if estado_jogo == 'jogo':
        desenha_mapa(ALTURA, LARGURA, tela, flicker, level)
        desenha_jogador(direcao, tela, contador, jogador_x, jogador_y)
        
        blinky = Fantasma(blinky_x, blinky_y, alvos[0], velocidade_fantasma[0], img_blinky, direcao_blinky, blinky_morto, blinky_caixa, 0, powerup, fantasmas_mortos)
        inky = Fantasma(inky_x, inky_y, alvos[1], velocidade_fantasma[1], img_inky, direcao_inky, inky_morto, inky_caixa, 1, powerup, fantasmas_mortos)
        pinky = Fantasma(pinky_x, pinky_y, alvos[2], velocidade_fantasma[2], img_pinky, direcao_pinky, pinky_morto, pinky_caixa, 2, powerup, fantasmas_mortos)
        clyde = Fantasma(clyde_x, clyde_y, alvos[3], velocidade_fantasma[3], img_clyde, direcao_clyde, clyde_morto, clyde_caixa, 3, powerup, fantasmas_mortos)
        
        desenha_pontuacao(pontuacao, tela, powerup, vidas)
        circulo_jogador = pygame.draw.circle(tela, 'black', (jogador_x + 10, jogador_y + 10), 10, 1)

        if not jogo_pausado:
            if powerup:
                velocidade_fantasma = [1, 1, 1, 1]
            else:
                velocidade_fantasma = [2, 2, 2, 2]
            
            if fantasmas_mortos[0]:
                velocidade_fantasma[0] = 2
            if fantasmas_mortos[1]:
                velocidade_fantasma[1] = 2
            if fantasmas_mortos[2]:
                velocidade_fantasma[2] = 2
            if fantasmas_mortos[3]:
                velocidade_fantasma[3] = 2
                
            if blinky_morto:
                velocidade_fantasma[0] = 4
            if inky_morto:
                velocidade_fantasma[1] = 4
            if pinky_morto:
                velocidade_fantasma[2] = 4
            if clyde_morto:
                velocidade_fantasma[3] = 4

            jogo_ganho = True
            for i in range(len(level)):
                if 1 in level[i] or 2 in level[i]:
                    jogo_ganho = False

            alvos = busca_alvos(blinky, inky, pinky, clyde, jogador_x, jogador_y, fantasmas_mortos, powerup)
            centro_x = jogador_x + 10
            centro_y = jogador_y + 10
            pode_virar = verifica_posicao(centro_x, centro_y, LARGURA, ALTURA, direcao, level)

            if movendo:
                jogador_x, jogador_y = mover_jogador(direcao, jogador_x, jogador_y, pode_virar, velocidade)
                if not blinky_morto and not blinky.na_caixa:
                    blinky_x, blinky_y, direcao_blinky = blinky.blinky_movimento()
                else:
                    blinky_x, blinky_y, direcao_blinky = blinky.clyde_movimento()

                if not pinky.morto and not pinky.na_caixa:
                    pinky_x, pinky_y, direcao_pinky = pinky.pinky_movimento()
                else:
                    pinky_x, pinky_y, direcao_pinky = pinky.clyde_movimento()
                
                if not inky.morto and not inky.na_caixa:
                    inky_x, inky_y, direcao_inky = inky.inky_movimento()
                else:
                    inky_x, inky_y, direcao_inky = inky.clyde_movimento()
                
                clyde_x, clyde_y, direcao_clyde = clyde.clyde_movimento()

            pontuacao, powerup, contador_power, fantasmas_mortos, tocar_som_comer, tocar_som_powerup = verifica_colisao(ALTURA, LARGURA, jogador_x, level, centro_x, centro_y, pontuacao, powerup, contador_power, fantasmas_mortos)

            if tocar_som_comer:
                if not pygame.mixer.get_busy():
                    som_bolinha.play()
            if tocar_som_powerup:
                som_powerup.play()

            if contador < 19:
                contador += 1
                if contador > 3:
                    flicker = False
            else:
                contador = 0
                flicker = True

            if powerup and contador_power < 300:
                contador_power += 1
            elif powerup and contador_power >= 300:
                contador_power = 0
                powerup = False
                fantasmas_mortos = [False, False, False, False]

            if contador_inicio < 240 and not fim_de_jogo and not jogo_ganho:
                movendo = False
                contador_inicio += 1
            elif not fim_de_jogo and not jogo_ganho:
                movendo = True
            else:
                movendo = False

            if not powerup:
                if (circulo_jogador.colliderect(blinky.rect) and not blinky.morto and not blinky.na_caixa) or \
                    (circulo_jogador.colliderect(inky.rect) and not inky.morto and not inky.na_caixa) or \
                    (circulo_jogador.colliderect(pinky.rect) and not pinky.morto and not pinky.na_caixa) or \
                    (circulo_jogador.colliderect(clyde.rect) and not clyde.morto and not clyde.na_caixa):
                    if vidas > 0:
                        som_morte.play()
                        vidas -= 1
                        powerup = False
                        contador_power = 0
                        contador_inicio = 0
                        jogador_x = 203
                        jogador_y = 335
                        direcao = 0
                        comando_direcao = 0
                        blinky_x, blinky_y, direcao_blinky = 200, 165, 0
                        inky_x, inky_y, direcao_inky = 175, 208, 2
                        pinky_x, pinky_y, direcao_pinky = 225, 208, 2
                        clyde_x, clyde_y, direcao_clyde = 200, 208, 2
                        fantasmas_mortos = [False, False, False, False]
                        blinky_morto = False
                        inky_morto = False
                        clyde_morto = False
                        pinky_morto = False
                    else:
                        fim_de_jogo = True
                        movendo = False
                        contador_inicio = 0
            
            if powerup and circulo_jogador.colliderect(blinky.rect) and not blinky.morto and not fantasmas_mortos[0]:
                blinky_morto, fantasmas_mortos[0] = True, True
                pontuacao += 2 ** fantasmas_mortos.count(True) * 100
                som_comer_fantasma.play()
            if powerup and circulo_jogador.colliderect(inky.rect) and not inky.morto and not fantasmas_mortos[1]:
                inky_morto, fantasmas_mortos[1] = True, True
                pontuacao += 2 ** fantasmas_mortos.count(True) * 100
                som_comer_fantasma.play()
            if powerup and circulo_jogador.colliderect(pinky.rect) and not pinky.morto and not fantasmas_mortos[2]:
                pinky_morto, fantasmas_mortos[2] = True, True
                pontuacao += 2 ** fantasmas_mortos.count(True) * 100
                som_comer_fantasma.play()
            if powerup and circulo_jogador.colliderect(clyde.rect) and not clyde.morto and not fantasmas_mortos[3]:
                clyde_morto, fantasmas_mortos[3] = True, True
                pontuacao += 2 ** fantasmas_mortos.count(True) * 100
                som_comer_fantasma.play()

            for i in range(4):
                if comando_direcao == i and pode_virar[i]:
                    direcao = i

            if jogador_x > LARGURA:
                jogador_x = -23
            elif jogador_x < -25:
                jogador_x = 410

            if blinky.na_caixa and blinky.morto: blinky_morto = False
            if inky.na_caixa and inky.morto: inky_morto = False
            if pinky.na_caixa and pinky.morto: pinky_morto = False
            if clyde.na_caixa and clyde.morto: clyde_morto = False

        if jogo_pausado:
            desenha_pausa()
        if fim_de_jogo:
            desenha_fim_de_jogo(pontuacao)
        if jogo_ganho:
            desenha_vitoria(pontuacao)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                executando = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    jogo_pausado = not jogo_pausado

                if event.key == pygame.K_ESCAPE and jogo_pausado:
                    powerup, contador_power, contador_inicio, jogador_x, jogador_y, direcao, comando_direcao, blinky_x, blinky_y, \
                    direcao_blinky, inky_x, inky_y, direcao_inky, pinky_x, pinky_y, direcao_pinky, clyde_x, clyde_y, direcao_clyde, \
                    fantasmas_mortos, blinky_morto, inky_morto, clyde_morto, pinky_morto, \
                    pontuacao, vidas, level, fim_de_jogo, jogo_ganho = reiniciar_jogo()
                    estado_jogo = 'menu'
                    jogo_pausado = False

                if not jogo_pausado: 
                    if event.key == pygame.K_RIGHT: comando_direcao = 0
                    if event.key == pygame.K_LEFT: comando_direcao = 1
                    if event.key == pygame.K_UP: comando_direcao = 2
                    if event.key == pygame.K_DOWN: comando_direcao = 3
                
                if event.key == pygame.K_SPACE and (fim_de_jogo or jogo_ganho):
                    som_comeco.play()
                    powerup, contador_power, contador_inicio, jogador_x, jogador_y, direcao, comando_direcao, blinky_x, blinky_y, \
                    direcao_blinky, inky_x, inky_y, direcao_inky, pinky_x, pinky_y, direcao_pinky, clyde_x, clyde_y, direcao_clyde, \
                    fantasmas_mortos, blinky_morto, inky_morto, clyde_morto, pinky_morto, \
                    pontuacao, vidas, level, fim_de_jogo, jogo_ganho = reiniciar_jogo()
                    jogo_pausado = False 

                if event.key == pygame.K_ESCAPE and (fim_de_jogo or jogo_ganho):
                    powerup, contador_power, contador_inicio, jogador_x, jogador_y, direcao, comando_direcao, blinky_x, blinky_y, \
                    direcao_blinky, inky_x, inky_y, direcao_inky, pinky_x, pinky_y, direcao_pinky, clyde_x, clyde_y, direcao_clyde, \
                    fantasmas_mortos, blinky_morto, inky_morto, clyde_morto, pinky_morto, \
                    pontuacao, vidas, level, fim_de_jogo, jogo_ganho = reiniciar_jogo()
                    estado_jogo = 'menu'
                    jogo_pausado = False

        pygame.display.flip()

pygame.quit()