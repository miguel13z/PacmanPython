import pygame
from config import *
from math import pi

def carregar_menu():
    fonte_titulo = pygame.font.Font('assets/font/press_start_2p.ttf', 56)
    texto_titulo = fonte_titulo.render('PACMAN', False, 'yellow')
    texto_rect = texto_titulo.get_rect(center=(LARGURA // 2, 70)) 
    tela.blit(texto_titulo, texto_rect)

    logo_pacman = pygame.image.load('assets/img/menu/imagem_menu.png')
    logo_pacman = pygame.transform.scale(logo_pacman, (215, 40))
    logo_rect = logo_pacman.get_rect(center=(LARGURA // 2, 120))
    tela.blit(logo_pacman, logo_rect)

    fonte_menu = pygame.font.Font('assets/font/press_start_2p.ttf', 13)
    texto_menu = fonte_menu.render('Pressione ENTER para começar', False, 'white')
    texto_menu_rect = texto_menu.get_rect(center=(LARGURA // 2, 250))
    tela.blit(texto_menu, texto_menu_rect)

    fonte_esc = pygame.font.Font('assets/font/press_start_2p.ttf', 13)
    texto_esc = fonte_esc.render('Pressione ESC para sair', False, 'white')
    texto_esc_rect = texto_esc.get_rect(center=(LARGURA // 2, 280))
    tela.blit(texto_esc, texto_esc_rect)

    fonte_creditos = pygame.font.Font('assets/font/press_start_2p.ttf', 10)
    texto_creditos_linha1 = fonte_creditos.render('Projeto de P1/LP1', False, 'white')
    rect_linha1 = texto_creditos_linha1.get_rect(center=(LARGURA // 2, 425))
    tela.blit(texto_creditos_linha1, rect_linha1)
    
    texto_creditos_linha2 = fonte_creditos.render('Pedro Henrique e Miguel Melo', False, 'white')
    rect_linha2 = texto_creditos_linha2.get_rect(center=(LARGURA // 2, 440)) 
    tela.blit(texto_creditos_linha2, rect_linha2)

def carregar_instrucoes():
    fonte_titulo = pygame.font.Font('assets/font/press_start_2p.ttf', 30)
    texto_titulo = fonte_titulo.render('Instruções', False, 'yellow')
    texto_rect = texto_titulo.get_rect(center=(LARGURA // 2, 70))
    tela.blit(texto_titulo, texto_rect)

    fonte_instrucoes = pygame.font.Font('assets/font/press_start_2p.ttf', 10)
    
    instrucoes = [
        "Use as SETAS para mover o Pacman.",
        "O jogo pode ser pausado com a tecla P.",
        "Coma todas as bolinhas para vencer.",
        "Cuidado com os fantasmas!",
        "Coma as pílulas de poder (maiores)",
        "para poder comer os fantasmas.",
    ]
    
    y_pos = 150
    for linha in instrucoes:
        texto_linha = fonte_instrucoes.render(linha, False, 'white')
        linha_rect = texto_linha.get_rect(center=(LARGURA // 2, y_pos))
        tela.blit(texto_linha, linha_rect)
        y_pos += 30

        if linha == "Cuidado com os fantasmas!":
            blinky_rect = img_blinky.get_rect(right=linha_rect.left - 10, centery=linha_rect.centery)
            tela.blit(img_blinky, blinky_rect)
            clyde_rect = img_clyde.get_rect(left=linha_rect.right + 10, centery=linha_rect.centery)
            tela.blit(img_clyde, clyde_rect)

    fonte_navegacao = pygame.font.Font('assets/font/press_start_2p.ttf', 13)
    texto_enter = fonte_navegacao.render('Pressione ENTER para começar', False, 'white')
    enter_rect = texto_enter.get_rect(center=(LARGURA // 2, 350))
    tela.blit(texto_enter, enter_rect)

    texto_esc = fonte_navegacao.render('Pressione ESC para voltar', False, 'white')
    esc_rect = texto_esc.get_rect(center=(LARGURA // 2, 380))
    tela.blit(texto_esc, esc_rect)

def desenha_fim_de_jogo(pontuacao):
    overlay = pygame.Surface((LARGURA, ALTURA), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))
    tela.blit(overlay, (0, 0))

    fonte_game_over = pygame.font.Font('assets/font/press_start_2p.ttf', 35)
    texto_game_over = fonte_game_over.render('GAME OVER', False, 'red')
    rect_game_over = texto_game_over.get_rect(center=(LARGURA // 2, ALTURA // 2 - 80))
    tela.blit(texto_game_over, rect_game_over)

    fonte_pontuacao = pygame.font.Font('assets/font/press_start_2p.ttf', 15)
    texto_pontuacao_final = fonte_pontuacao.render(f'Pontuação Final: {pontuacao}', True, 'white')
    rect_pontuacao_final = texto_pontuacao_final.get_rect(center=(LARGURA // 2, ALTURA // 2))
    tela.blit(texto_pontuacao_final, rect_pontuacao_final)

    fonte_instrucoes = pygame.font.Font('assets/font/press_start_2p.ttf', 10)
    texto_reiniciar = fonte_instrucoes.render('Pressione ESPAÇO para reiniciar', False, 'white')
    rect_reiniciar = texto_reiniciar.get_rect(center=(LARGURA // 2, ALTURA // 2 + 80))
    tela.blit(texto_reiniciar, rect_reiniciar)
    
    texto_menu = fonte_instrucoes.render('Pressione ESC para voltar ao Menu', False, 'white')
    rect_menu = texto_menu.get_rect(center=(LARGURA // 2, ALTURA // 2 + 110))
    tela.blit(texto_menu, rect_menu)

def desenha_vitoria(pontuacao):
    overlay = pygame.Surface((LARGURA, ALTURA), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))
    tela.blit(overlay, (0, 0))

    fonte_vitoria = pygame.font.Font('assets/font/press_start_2p.ttf', 30)
    texto_vitoria = fonte_vitoria.render('VOCÊ VENCEU!', False, 'green')
    rect_vitoria = texto_vitoria.get_rect(center=(LARGURA // 2, ALTURA // 2 - 80))
    tela.blit(texto_vitoria, rect_vitoria)

    fonte_pontuacao = pygame.font.Font('assets/font/press_start_2p.ttf', 15)
    texto_pontuacao_final = fonte_pontuacao.render(f'Pontuação Final: {pontuacao}', False, 'white')
    rect_pontuacao_final = texto_pontuacao_final.get_rect(center=(LARGURA // 2, ALTURA // 2))
    tela.blit(texto_pontuacao_final, rect_pontuacao_final)

    fonte_instrucoes = pygame.font.Font('assets/font/press_start_2p.ttf', 10)
    texto_reiniciar = fonte_instrucoes.render('Pressione ESPAÇO para reiniciar', False, 'white')
    rect_reiniciar = texto_reiniciar.get_rect(center=(LARGURA // 2, ALTURA // 2 + 80))
    tela.blit(texto_reiniciar, rect_reiniciar)
    
    texto_menu = fonte_instrucoes.render('Pressione ESC para voltar ao Menu', False, 'white')
    rect_menu = texto_menu.get_rect(center=(LARGURA // 2, ALTURA // 2 + 110))
    tela.blit(texto_menu, rect_menu)

def desenha_pausa():
    overlay = pygame.Surface((LARGURA, ALTURA), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))
    tela.blit(overlay, (0, 0))

    fonte_pausa = pygame.font.Font('assets/font/press_start_2p.ttf', 30)
    texto_pausa = fonte_pausa.render('JOGO PAUSADO', False, 'yellow')
    rect_pausa = texto_pausa.get_rect(center=(LARGURA // 2, ALTURA // 2 - 60))
    tela.blit(texto_pausa, rect_pausa)

    fonte_instrucao = pygame.font.Font('assets/font/press_start_2p.ttf', 12)
    texto_continuar = fonte_instrucao.render('Pressione P para continuar', False, 'white')
    rect_continuar = texto_continuar.get_rect(center=(LARGURA // 2, ALTURA // 2 + 20))
    tela.blit(texto_continuar, rect_continuar)
    
    texto_menu = fonte_instrucao.render('Pressione ESC para voltar ao Menu', False, 'white')
    rect_menu = texto_menu.get_rect(center=(LARGURA // 2, ALTURA // 2 + 50))
    tela.blit(texto_menu, rect_menu)

def desenha_pontuacao(pontuacao, tela, powerup, vidas):
    fonte_pontuacao = pygame.font.Font('assets/font/press_start_2p.ttf', 12)
    texto_pontuacao = fonte_pontuacao.render(f'Score: {pontuacao}', False, 'white')
    fonte = pygame.font.Font('assets/font/press_start_2p.ttf', 10)
    tela.blit(texto_pontuacao, (10,460))
    if powerup:
        pygame.draw.circle(tela, 'blue', (148, 465), 5)
        
    for i in range(vidas):
        tela.blit(pygame.transform.scale(imagens_jogador[0], (15, 15)), (350 + i * 20, 458))

def reiniciar_jogo():
    powerup = False
    contador_power = 0
    contador_inicio = 0
    jogador_x = 203
    jogador_y = 335
    direcao = 0
    comando_direcao = 0
    blinky_x = 200
    blinky_y = 165
    direcao_blinky = 0
    inky_x = 175
    inky_y = 208
    direcao_inky = 2
    pinky_x = 225
    pinky_y = 208
    direcao_pinky = 2
    clyde_x = 200
    clyde_y = 208
    direcao_clyde = 2
    fantasmas_mortos = [False, False, False, False]
    blinky_morto = False
    inky_morto = False
    clyde_morto = False
    pinky_morto = False
    pontuacao = 0
    vidas = 3
    level = copy.deepcopy(mapa)
    fim_de_jogo = False
    jogo_ganho = False
    
    return powerup, contador_power, contador_inicio, jogador_x, jogador_y, direcao, comando_direcao, blinky_x, blinky_y, \
        direcao_blinky, inky_x, inky_y, direcao_inky, pinky_x, pinky_y, direcao_pinky, clyde_x, clyde_y, direcao_clyde, \
        fantasmas_mortos, blinky_morto, inky_morto, clyde_morto, pinky_morto, pontuacao, vidas, level, fim_de_jogo, jogo_ganho

def verifica_colisao(altura, largura, jogador_x, level, centro_x, centro_y, pontuacao, power, contador_power, fantasmas_mortos):
    num1 = altura // 32
    num2 = largura // 30
    som_comer = False
    som_powerup = False
    if 0 < jogador_x < 400:
        linha = centro_y // num1
        coluna = centro_x // num2

        if level[linha][coluna] == 1:
            level[linha][coluna] = 0
            pontuacao += 10
            som_comer = True

        if level[linha][coluna] == 2:
            level[linha][coluna] = 0
            pontuacao += 50
            power = True
            contador_power = 0
            fantasmas_mortos = [False, False, False, False]
            som_powerup = True


    return pontuacao, power, contador_power, fantasmas_mortos, som_comer, som_powerup

def desenha_mapa(altura, largura, tela, flicker, mapa_atual):
    num1 = altura // 32
    num2 = largura // 30
    for i in range(len(mapa_atual)):
        for j in range(len(mapa_atual[i])):
            if mapa_atual[i][j] == 1:
                pygame.draw.circle(tela, 'white', (j * num2 + (0.5 * num2), i * num1 + (0.5 * num1)), 2)
            if mapa_atual[i][j] == 2 and not flicker:
                pygame.draw.circle(tela, 'white', (j * num2 + (0.5 * num2), i * num1 + (0.5 * num1)), 5)
            if mapa_atual[i][j] == 3:
                pygame.draw.line(tela, 'blue', (j * num2 + (0.5 * num2), i * num1), (j * num2 + (0.5 * num2), i * num1 + num1), 3)
            if mapa_atual[i][j] == 4:
                pygame.draw.line(tela, 'blue', (j * num2, i * num1 + (0.5 * num1)), (j * num2 + num2, i * num1 + (0.5 * num1)), 3)
            if mapa_atual[i][j] == 5:
                pygame.draw.arc(tela, 'blue', [(j * num2 - (num2 * 0.4)) - 2, (i * num1 + (0.5 * num1)), num2, num1], 0, pi / 2, 3)
            if mapa_atual[i][j] == 6:
                pygame.draw.arc(tela, 'blue', [(j * num2 + (num2 * 0.5)), (i * num1 + (0.5 * num1)), num2, num1], pi / 2, pi, 3)
            if mapa_atual[i][j] == 7:
                pygame.draw.arc(tela, 'blue', [(j * num2 + (num2 * 0.5)), (i * num1 - (0.4 * num1)), num2, num1], pi, 3 * pi / 2, 3)
            if mapa_atual[i][j] == 8:
                pygame.draw.arc(tela, 'blue', [(j * num2 - (num2 * 0.4)) - 2, (i * num1 - (0.4 * num1)), num2, num1], 3 * pi / 2, 2 * pi, 3)
            if mapa_atual[i][j] == 9:
                pygame.draw.line(tela, 'white', (j * num2, i * num1 + (0.5 * num1)), (j * num2 + num2, i * num1 + (0.5 * num1)), 3)

imagens_jogador = []
for i in range(1, 5):
    imagens_jogador.append(pygame.transform.scale(pygame.image.load(f'assets/img/jogador/{i}.png'), (20, 20)))

def desenha_jogador(direcao, tela, contador, jogador_x, jogador_y):
    if direcao == 0:
        tela.blit(imagens_jogador[contador // 5], (jogador_x, jogador_y))
    if direcao == 1:
        tela.blit(pygame.transform.flip(imagens_jogador[contador // 5], True, False), (jogador_x, jogador_y))
    if direcao == 2:
        tela.blit(pygame.transform.rotate(imagens_jogador[contador // 5], 90), (jogador_x, jogador_y))
    if direcao == 3:
        tela.blit(pygame.transform.rotate(imagens_jogador[contador // 5], 270), (jogador_x, jogador_y))

def verifica_posicao(centro_x, centro_y, largura, altura, direcao, level):
    pode_virar = [False, False, False, False]
    num1 = altura // 32
    num2 = largura // 30
    num3 = num2 // 2

    if centro_x // num2 < 29:
        if direcao == 0:
            if level[centro_y // num1][(centro_x - num3) // num2] < 3:
                pode_virar[1] = True
        if direcao == 1:
            if level[centro_y // num1][(centro_x + num3) // num2] < 3:
                pode_virar[0] = True
        if direcao == 2:
            if level[(centro_y + num3) // num1][centro_x // num2] < 3:
                pode_virar[3] = True
        if direcao == 3:
            if level[(centro_y - num3) // num1][centro_x // num2] < 3:
                pode_virar[2] = True

        centro_tile_x_min = (num2 // 2) - 2
        centro_tile_x_max = (num2 // 2) + 2
        centro_tile_y_min = (num1 // 2) - 2
        centro_tile_y_max = (num1 // 2) + 2
        
        if direcao == 2 or direcao == 3: 
            if centro_tile_x_min <= centro_x % num2 <= centro_tile_x_max:
                if level[(centro_y + num3) // num1][centro_x // num2] < 3:
                    pode_virar[3] = True
                if level[(centro_y - num3) // num1][centro_x // num2] < 3:
                    pode_virar[2] = True
            if centro_tile_y_min <= centro_y % num1 <= centro_tile_y_max:
                if level[centro_y // num1][(centro_x - num2) // num2] < 3:
                    pode_virar[1] = True
                if level[centro_y // num1][(centro_x + num2) // num2] < 3:
                    pode_virar[0] = True

        if direcao == 0 or direcao == 1: 
            if centro_tile_x_min <= centro_x % num2 <= centro_tile_x_max:
                if level[(centro_y + num1) // num1][centro_x // num2] < 3:
                    pode_virar[3] = True
                if level[(centro_y - num1) // num1][centro_x // num2] < 3:
                    pode_virar[2] = True
            if centro_tile_y_min <= centro_y % num1 <= centro_tile_y_max:
                if level[centro_y // num1][(centro_x - num3) // num2] < 3:
                    pode_virar[1] = True
                if level[centro_y // num1][(centro_x + num3) // num2] < 3:
                    pode_virar[0] = True
    else:
        pode_virar[0] = True
        pode_virar[1] = True

    return pode_virar

def mover_jogador(direcao, jogador_x, jogador_y, pode_virar, velocidade):
    # 0 -> direita, 1 -> esquerda, 2 -> cima, 3 -> baixo
    if direcao == 0 and pode_virar[0]:
        jogador_x += velocidade
    elif direcao == 1 and pode_virar[1]:
        jogador_x -= velocidade
    if direcao == 2 and pode_virar[2]:
        jogador_y -= velocidade
    elif direcao == 3 and pode_virar[3]:
        jogador_y += velocidade

    return jogador_x, jogador_y

def busca_alvos(blinky, inky, pinky, clyde, jogador_x, jogador_y, fantasmas_mortos, powerup):
    if jogador_x < 210:
        fuga_x = 420
    else:
        fuga_x = 0
    if jogador_y < 210:
        fuga_y = 420
    else:
        fuga_y = 0

    local_retorno = (200, 208)
    saida_caixa = (211, 50)

    if powerup:
        if not blinky.morto and not fantasmas_mortos[0]:
            blink_alvo = (fuga_x, fuga_y)
        elif blinky.na_caixa:
            blink_alvo = saida_caixa
        else:
            blink_alvo = local_retorno

        if not inky.morto and not fantasmas_mortos[1]:
            ink_alvo = (fuga_x, jogador_y)
        elif inky.na_caixa:
            ink_alvo = saida_caixa
        else:
            ink_alvo = local_retorno

        if not pinky.morto and not fantasmas_mortos[2]:
            pink_alvo = (jogador_x, fuga_y)
        elif pinky.na_caixa:
            pink_alvo = saida_caixa
        else:
            pink_alvo = local_retorno

        if not clyde.morto and not fantasmas_mortos[3]:
            clyd_alvo = (450, 450)
        elif clyde.na_caixa:
            clyd_alvo = saida_caixa
        else:
            clyd_alvo = local_retorno

    else:
        if not blinky.morto:
            if blinky.na_caixa:
                blink_alvo = saida_caixa
            else:
                blink_alvo = (jogador_x, jogador_y)
        else:
            blink_alvo = local_retorno

        if not inky.morto:
            if inky.na_caixa:
                ink_alvo = saida_caixa
            else:
                ink_alvo = (jogador_x, jogador_y)
        else:
            ink_alvo = local_retorno

        if not pinky.morto:
            if pinky.na_caixa:
                pink_alvo = saida_caixa
            else:
                pink_alvo = (jogador_x, jogador_y)
        else:
            pink_alvo = local_retorno

        if not clyde.morto:
            if clyde.na_caixa:
                clyd_alvo = saida_caixa
            else:
                clyd_alvo = (jogador_x, jogador_y)
        else:
            clyd_alvo = local_retorno

    return [blink_alvo, ink_alvo, pink_alvo, clyd_alvo]