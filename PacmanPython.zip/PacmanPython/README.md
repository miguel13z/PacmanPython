Olá, esse projeto traz o jogo pacman feito totalmente em python e utilizando a biblioteca pygame.

É necessário conter informações de como instalar e rodar o jogo